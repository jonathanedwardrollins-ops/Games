const QUESTIONS = [
  { q: "How much does the average American spend on coffee in a year?", a: "Around $1,100 (varies by source)." },
  { q: "What percentage of U.S. currency is contaminated with cocaine residue?", a: "Often 80–90% of bills show trace amounts." },
  { q: "How many hot dogs are eaten on the 4th of July in the U.S.?", a: "About 150 million." },
  { q: "How many bones are in the adult human skeleton?", a: "206 bones." },
  { q: "Which U.S. state has the most coastline?", a: "Alaska." },
];